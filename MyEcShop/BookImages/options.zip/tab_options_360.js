/**
 * define tabOptionsPage 
 * 
 ***/
cr.define('options', function() {
  var OptionsPage = options.OptionsPage;

  function TabOptionsPage() {
    OptionsPage.call(this, 'tab', '\u9009\u9879 - \u6807\u7B7E\u680F', 'tabOptionsPage');
  }

  cr.addSingletonGetter(TabOptionsPage);
  
  TabOptionsPage.prototype = {
    __proto__: options.OptionsPage.prototype,
    
    initializePage: function(){
      OptionsPage.prototype.initializePage.call(this);

    },
  };

  return {
    TabOptionsPage: TabOptionsPage
  };
});
