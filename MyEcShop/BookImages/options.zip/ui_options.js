/**
 * define UIOptions : Third Party UI Options Page
 * 
 ***/
cr.define('options', function() {
  var OptionsPage = options.OptionsPage;
  
  function UIOptions() {
      OptionsPage.call(this, 'ui', '\u9009\u9879 - \u754C\u9762\u8BBE\u7F6E', 'uiPage');
    }
  
  cr.addSingletonGetter(UIOptions);
  
  UIOptions.prototype = {
    __proto__: options.OptionsPage.prototype,
    
    initializePage: function(){
      OptionsPage.prototype.initializePage.call(this);

      Preferences.getInstance().addEventListener('se.virtual.tab_unactive_color', function() {
        $$('#ui_SetTabUnactiveColor').attr('disabled', !$$('[pref="se.virtual.tab_unactive_color"]').attr('checked'));
      });

      $('ui_SetTabUnactiveColor').onclick = function(event) {
        chrome.send('seSetupTabUnactiveColor');
      };

      Preferences.getInstance().addEventListener('se.browser.enable_systray', function() {
        $$('[pref="se.browser.enable_systray"]').parents('.checkbox').nextAll('.sub-item').find(':checkbox').attr('disabled', 
                              !$$('[pref="se.browser.enable_systray"]').attr('checked'));
      });

    }
  };
  
  return {
      UIOptions: UIOptions
    };
});

