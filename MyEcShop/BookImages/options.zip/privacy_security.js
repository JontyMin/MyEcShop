/**
 * define tpMoreOptions : Third Party More Options Page
 *
 ***/
cr.define('options', function() {
  var OptionsPage = options.OptionsPage;

  function TpMoreOptions() {
    OptionsPage.call(this, 'privacy', '\u9009\u9879 - \u641C\u7D22\u680F', 'privacyPage');
  }

  cr.addSingletonGetter(TpMoreOptions);

  TpMoreOptions.prototype = {
    __proto__: options.OptionsPage.prototype,

    initializePage: function() {
      OptionsPage.prototype.initializePage.call(this);

      Preferences.getInstance().addEventListener('profile.clear_browsing_data_on_exit_key', function() {
        $$('#privacyPage .clear_items input').attr('disabled', !$$('[pref="profile.clear_browsing_data_on_exit_key"]').attr('checked'));
      });

      var that = this;
      this.addEventListener('visibleChange', function(event) {
        tpGetInitOptionsData();
        tpGetInitDownloaderData();
      });

      $('privacy_OpenClearBrowsingDataDialog').onclick = function(event) {
        chrome.send('seOpenClearBrowsingDataDialog');
      };
    },
    initUIData: function() {
      var tpInitOptionsData = [
          'IDS_MORE_SETTING_DLG_OPEN_BOOKMARK',
          'IDS_MORE_SETTING_DLG_OPEN_ADDR_BOX_URL',
          'IDS_MORE_SETTING_DLG_ENABLE_MOUSE_GESTURE',
          'IDS_MORE_SETTING_DLG_ENABLE_MOUSE_GESTURE_TIPS',
          'IDS_THIRDPARTY_DOWNLOADER_SELECT_DEFAULTUSE_DOWNLOADER',
      // 'IDS_THIRDPARTY_DOWNLOADER_ASK_ME_TO_SELECT_BEFOREDOWNLOAD',
          'IDS_MORE_SETTING_DLG_RIGHT_BUTTON_TO_CLOSE_TAB',
          'IDS_MORE_SETTING_DLG_ENABLE_MINIMIZE_TO_SYSTEM_TRAY',
      // 'IDS_MORE_SETTING_DLG_ENABLE_GOOGLE_SYNC',
          'IDS_MORE_SETTING_DLG_CLEAR_WHEN_EXIT2',
          'IDS_MORE_SETTING_DLG_CONFIRM_CLOSE_WINDOW_TITLE',
          'IDS_MORE_SETTING_DLG_DOUBLE_CLICK_TO_CLOSE_TAB',
          'IDS_MORE_SETTING_DLG_DRAG_TEXT_TO_SEARCH',
          'IDS_MORE_SETTING_DLG_HIDE_INACTIVE_TAB_CLOSE',
          'IDS_MORE_SETTING_DLG_NEW_TAB_IN_FOREGROUND',
          'IDS_SHOW_BAR_ON_VIDEO'
        ],
        tpOptionsData = templateData['tpOptionsInitData'];

      tpInitOptionsData.forEach(function(key) {
        var tpOptionData = tpOptionsData[key];
        var options = tpOptionData['options'];
        var value = tpOptionData['value'];
        if (!options || options.length == 0) { //checkbox
          var checkboxEl = $('CHECKBOX_' + key);
          if (!checkboxEl) return;
          checkboxEl.checked = !!value;
          checkboxEl.onchange = function() {
            var k = this.id.replace('CHECKBOX_', '');
            var confirmed = true;
            if (k == 'IDS_MORE_SETTING_DLG_ENABLE_GOOGLE_SYNC') {
              var text_str = $('sync-unlogined-switch-confirm-text').innerHTML;
              if (PersonalOptions && PersonalOptions.is360SyncSetupCompleted()) {
                text_str = $('sync-logined-switch-confirm-text').innerHTML;
              }
              confirmed = window.confirm(text_str);
            }
            if (confirmed) {
              tpOptionData[k] = this.checked ? 1 : 0;
              tpSetOptionsData(k, tpOptionData[k]);
            }
            else {
              this.checked = !this.checked;
            }
          }
        } else { //select
          var str = '', selected = '', selectEl = $('SELECT_' + key);
          options.forEach(function(option, idx) {
            selected = (value == idx) ? 'selected' : '';
            str += '<option value="' + idx + '" ' + selected + '>' + templateData[option] + '</option>';
          });
          selectEl.innerHTML = str;
          selectEl.onchange = function() {
            var k = this.id.replace('SELECT_', '');
            tpOptionsData[k].value = this.value;
            templateData['tpOptionsInitData'] = tpOptionsData;
            tpSetOptionsData(k, this.value);
          }
        }
      });
    },
    /** added by caolong 2011-05-04 18:34:21
    * Update the Default Browsers section based on the current state.
    * @private
    * @param {string} statusString Description of the current default state.
    * @param {boolean} isDefault Whether or not the browser is currently
    *     default.
    * @param {boolean} canBeDefault Whether or not the browser can be default.
    */
    updateCurrentBossKeyState_: function(enableState, bossKeyValue) {
//      var label = $('currentBossKeyState');
//      label.textContent = enableState + bossKeyValue;
    },
    updateUIData: function(data) {
      for (var key in data) {
        var tpOptionData = templateData['tpOptionsInitData'][key],
          options = tpOptionData['options'],
          value = tpOptionData['value'];

        if (!options || options.length == 0) {
          try{
            $('CHECKBOX_' + key).checked = !!value;
          }catch(e){}
        } else {
          var str = '', selected = '', selectEl = $('SELECT_' + key);
          options.forEach(function(option, idx) {
            selected = (value == idx) ? 'selected' : '';
            str += '<option value="' + idx + '" ' + selected + '>' + templateData[option] + '</option>';
          });
          selectEl.innerHTML = str;
        }
      }


    }
  };


  //update bosskey by caolong 2011-05-31 21:23:29
  TpMoreOptions.updateCurrentBossKeyState = function(statusString, bossKey) {
    if (!cr.isChromeOS) {
      TpMoreOptions.getInstance().updateCurrentBossKeyState_(statusString, bossKey);
    }
  };

  return {
    TpMoreOptions: TpMoreOptions
  };
});
//���� ��ǰ���յ������� �� ���ص����ݻ��� ͬ��������
var tpOptionsReceiveDataTypes = {dataGot: 1, dataChanged: 2}, tpOptionsReceiveDataType = null ;
function tpSetDefaultOptionsReceiveDataType(){
  tpOptionsReceiveDataType = null;
}
function tpGetOptionsData(key){
  if (!key){
    return ;
  }
  chrome.send('tpOptionGetKey', [key]);
}

function tpSetOptionsData(key, value){
  if (!key || tpOptionsReceiveDataType === tpOptionsReceiveDataTypes.dataChanged){
    return;
  }
  //console.log('tpSetOptionsData', key, value);
  if (key == 'IDS_MORE_SETTING_DLG_ENABLE_GOOGLE_SYNC'){
    templateData['tpOptionsInitData']['IDS_MORE_SETTING_DLG_ENABLE_GOOGLE_SYNC'].value = parseInt(value);
//    if (value == 1){
//      chrome.send('tpShowSyncLogoutDialog');
//    }
  }
  chrome.send('tpOptionSetKey', [key, value.toString()]);
  onOptionSavedSuccessfully();
}

var gOptionData;
function onTpOptionGetKey(data, downloaderData){
  if (!data){
    return ;
  }
  gOptionData = data;

  var initData = templateData['tpOptionsInitData'];
  if (!initData){  //define templateData.tpOptionsInitData
    initData = templateData['tpOptionsInitData'] = {};
  }

  //�ص����� ��д��templateData
  for(var key in data){
    initData[key] = data[key][0];  //��Ϊ ����Ͷ��� value�ṹһ�£�����array
  }

  if (downloaderData) {
    initData['IDS_THIRDPARTY_DOWNLOADER_SELECT_DEFAULTUSE_DOWNLOADER'] = downloaderData;
    var arr_options = [];
    for (var key in downloaderData['options']) {
    templateData[key] = downloaderData['options'][key];
    arr_options.push(key);
    }
    initData['IDS_THIRDPARTY_DOWNLOADER_SELECT_DEFAULTUSE_DOWNLOADER']['options'] = arr_options;
  }

  //����build UI
  tpOptionsReceiveDataType = tpOptionsReceiveDataTypes.dataGot;
  options.TpMoreOptions.prototype.initUIData();
  tpSetDefaultOptionsReceiveDataType();
  options.MouseGestures.prototype.initUIData();
}

function onTpGetExternalDownloaderName(data, value) {
  onTpOptionGetKey(gOptionData, {options: data, value: value});
}

function onTpOptionSetKey(data){

}

function onTpOptionDataChanged(data){
  if (!data){
    return ;
  }

  var initData = templateData['tpOptionsInitData'];
  if (!initData){
    return ;
  }
  for(var key in data){
    initData[key] = data[key][0];
  }

  //����  UI
  tpOptionsReceiveDataType = tpOptionsReceiveDataTypes.dataChanged;
  options.TpMoreOptions.prototype.updateUIData(data);
  tpSetDefaultOptionsReceiveDataType();
}

function tpGetInitOptionsData(){
  chrome.send('tpOptionGetKey');
}

function tpGetInitDownloaderData() {
  chrome.send('tpGetExternalDownloaderName');
}
