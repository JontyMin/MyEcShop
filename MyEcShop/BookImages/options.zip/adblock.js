
/**
 * define ShortCut : Third Party UI Options Page
 * 
 ***/
cr.define('options', function() {
  var OptionsPage = options.OptionsPage;
  
  function AdBlock() {
      OptionsPage.call(this, 'adblock', '选项 - 广告过滤', 'adblockPage');
  }
  
  cr.addSingletonGetter(AdBlock);

  AdBlock.prototype = {
    __proto__: options.OptionsPage.prototype,
    initializePage: function(){

      OptionsPage.prototype.initializePage.call(this);

      $('msgExBlockButton').onclick = function(event) {
        OptionsPage.navigateToPage('adblockException');
      };
      $('adblockEnable').onclick = function(e){
        jQuery('.adblockMode').attr('disabled', !e.target.checked);
      };
    }
  };
  
  return {
      AdBlock: AdBlock
    };
});
