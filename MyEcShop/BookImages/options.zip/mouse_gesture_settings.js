// Copyright (c) 2012 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

cr.define('options', function() {

  var OptionsPage = options.OptionsPage;

  //////////////////////////////////////////////////////////////////////////////
  // MouseGestureSettings class:

  /**
   * Encapsulated handling of mouse gesture settings page.
   * @constructor
   */
  function MouseGestureSettings() {
    this.activeNavTab = null;
    OptionsPage.call(this, 'mouse_gesture', '鼠标手势设置',
                     'mouse-gesture-settings-page');
  }

  cr.addSingletonGetter(MouseGestureSettings);

  MouseGestureSettings.prototype = {
    __proto__: OptionsPage.prototype,

    initializePage: function() {
      OptionsPage.prototype.initializePage.call(this);
    }
  };
  return {
    MouseGestureSettings: MouseGestureSettings
  };
});

