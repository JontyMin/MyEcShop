/**
 * define ShortCut : Third Party UI Options Page
 * 
 ***/
cr.define('options', function() {
  var OptionsPage = options.OptionsPage;
  
  function AdvanceSettings() {
      OptionsPage.call(this, 'advance', '\u9009\u9879 - 高级设置', 'advancePage');
  }
  
  cr.addSingletonGetter(AdvanceSettings);

  AdvanceSettings.prototype = {
    __proto__: options.OptionsPage.prototype,
    
    initializePage: function(){
      OptionsPage.prototype.initializePage.call(this);
      $('searchEngineSettingsButton').onclick = function(event) {
        OptionsPage.navigateToPage('search_engine');
      };

      Preferences.getInstance().addEventListener('safemon_lock_search', function(e) {
        switch (e.value.value) {
          case 0:
            break;
          case 1:
            $('safemonLockSearchTips').hidden = false;
            $('safemonLockSearchButton').innerHTML = '修改';
            $('safemonLockSearchButton').hidden = false;
            break;
          case 2:
            $('safemonLockSearchTips').hidden = true;
            $('safemonLockSearchButton').innerHTML = '开启强力防护';
            $('safemonLockSearchButton').hidden = false;
            break;
        }
      });
      $('safemonLockSearchButton').onclick = function(event) {
        chrome.send('LaunchSafemonLockSearch');
      };
      
      /*
      $('mouseGestureSettingsButton').onclick = function(event) {
        OptionsPage.navigateToPage('mouse_gesture');
      };
      */

      $('button_save_images').onclick = function(event) {
        chrome.send('selectSaveImagesQuicklyLocation');
      };
    }
  };

  return {
    AdvanceSettings: AdvanceSettings
  };
});
