// Copyright (c) 2012 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

cr.define('options', function() {
  const OptionsPage = options.OptionsPage;
  const ArrayDataModel = cr.ui.ArrayDataModel;

  //
  // BrowserOptions class
  // Encapsulated handling of browser options page.
  //
  function BrowserOptions() {
    OptionsPage.call(this, 'browser',
                     templateData.browserPageTabTitle,
                     'browserPage');
  }

  cr.addSingletonGetter(BrowserOptions);

  BrowserOptions.prototype = {
    // Inherit BrowserOptions from OptionsPage.
    __proto__: options.OptionsPage.prototype,

    startup_pages_pref_: {
      'name': 'session.urls_to_restore_on_startup',
      'disabled': false
    },

    /**
     * At autocomplete list that can be attached to a text field during editing.
     * @type {HTMLElement}
     * @private
     */
    autocompleteList_: null,

    // The cached value of the instant.confirm_dialog_shown preference.
    instantConfirmDialogShown_: false,

    /**
     * Initialize BrowserOptions page.
     */
    initializePage: function() {
      // Call base class implementation to start preference initialization.
      OptionsPage.prototype.initializePage.call(this);

      this.addEventListener('visibleChange', function(event) {
        tpGetInitOptionsData();
        tpGetInitDownloaderData();
      });

      // Wire up controls.
      $('startupUseCurrentButton').onclick = function(event) {
        chrome.send('setStartupPagesToCurrentPages');
      };
      $$('.defaultSearchEngine').on('change', this.setDefaultSearchEngine_);

      var self = this;


      Preferences.getInstance().addEventListener('instant.confirm_dialog_shown',
          this.onInstantConfirmDialogShownChanged_.bind(this));

      Preferences.getInstance().addEventListener('instant.enabled',
          this.onInstantEnabledChanged_.bind(this));

      Preferences.getInstance().addEventListener('safemonLockHomePage', function(e) {
        switch (e.value.value) {
          case 0:
            break;
          case 1:
            $('safemonLockHomePageTip').hidden = false;
            $$('[name="startup"]').attr('disabled', 'disabled');
            break;
          case 2:
            $('safemonLockHomePageButton').hidden = false;
            $$('[name="startup"]').removeAttr('disabled');
            break;
        }
        $('changeHomePageButton').dataset.smls = e.value.value;  // Set the safemonLockStatus mark
      });

      $('changeHomePageButton').onclick = function(event) {
        if (this.dataset.smls == '0') {  // Check the safemonLockStatus mark
          $$('.mask').show();
          $$('#homepage-setting-popup textarea')[0].value = $('startupShowPagesText').textContent.replace(', ', '\n');
          $$('#homepage-setting-popup').show();
        } else {
          //chrome.send('LaunchSafemonLockHomePage');
          chrome.send('HandleModifyHomePage', ['BrowserOptions.onHandleModifyHomePage']);
        }
      };
 
      $('safemonLockHomePageButton').onclick = function(event) {
        chrome.send('LaunchSafemonLockHomePage');
      };
      
      chrome.send('getDefaultAlterSearchEngine');
	  
      /*var homepageField = $('homepageURL');
      homepageField.addEventListener('focus', function(event) {
        self.autocompleteList_.attachToInput(homepageField);
      });
      homepageField.addEventListener('blur', function(event) {
        self.autocompleteList_.detach();
      });
      homepageField.addEventListener('keydown', function(event) {
        // Remove focus when the user hits enter since people expect feedback
        // indicating that they are done editing.
        if (event.keyIdentifier == 'Enter')
          homepageField.blur();
      });*/

      // Text fields may change widths when the window changes size, so make
      // sure the suggestion list stays in sync.
      window.addEventListener('resize', function() {
        self.autocompleteList_.syncWidthToInput();
      });

      // Ensure that changes are committed when closing the page.
      window.addEventListener('unload', function() {
        if (document.activeElement == homepageField)
          homepageField.blur();
      });

      function setHomepageText() {
        $$('#homepage-setting-popup textarea')[0].value = this.dataset.url;
      }

      $('hp-btn-hao360').addEventListener('click', setHomepageText, false);
      $('hp-btn-ntp').addEventListener('click', setHomepageText, false);
      $('hp-btn-360so').addEventListener('click', setHomepageText, false);

      $$('#homepage-setting-popup .green-btn').live('click', function(){
          var url_arr = [], arr = $$('#homepage-setting-popup textarea')[0].value.trim().split('\n');
          for (var i = 0, len = arr.length; i < len; i++) {
            if (arr[i].length > 0) url_arr.push(arr[i]);
          }
          chrome.send('SetStartupPages', url_arr);
          window.userGesture = true;
          $$('#homepage-setting-popup').hide();
          $$('.mask').hide();
      });
      $$('#homepage-setting-popup .gray-btn, #homepage-setting-popup .btn-close').live('click', function(){
          $$('#homepage-setting-popup').hide();
          $$('.mask').hide();
      });
 
      if (!cr.isChromeOS) {
        $('defaultBrowserUseAsDefaultButton').onclick = function(event) {
          chrome.send('becomeDefaultBrowser');
        };

        $('autoLaunch').addEventListener('click',
                                         this.handleAutoLaunchChanged_);
      }

      var startupPagesList = $('startupPagesList');
      options.browser_options.StartupPageList.decorate(startupPagesList);
 
      startupPagesList.autoExpands = true;

      // Check if we are in the guest mode.
      if (cr.commandLine && cr.commandLine.options['--bwsi']) {
        // Hide the startup section.
        $('startupSection').hidden = true;
      } else {
        // Initialize control enabled states.
        /*
        Preferences.getInstance().addEventListener(
            'session.restore_on_startup',
            this.updateCustomStartupPageControlStates_.bind(this));
        */
        Preferences.getInstance().addEventListener(
            'session.restore_on_startup',
            function(e) {
              var val = e.value.value;
              if (val == 0 || val == 360 || val == 361) {
                $$('[name=startup][value="4"]')[0].checked = true;
                var url = ['se://newtab', 'http://hao.360.cn', 'se://last'][val % 359];
                $('startupShowPagesText').textContent = $$('#homepage-setting-popup textarea')[0].value = url;
                chrome.send('SetStartupPages', [url]);
              }
            });

        Preferences.getInstance().addEventListener(
            this.startup_pages_pref_.name,
            this.handleStartupPageListChange_.bind(this));

        //this.updateCustomStartupPageControlStates_();
      }

      var suggestionList = new cr.ui.AutocompleteList();
      suggestionList.autoExpands = true;
      suggestionList.suggestionUpdateRequestCallback =
          this.requestAutocompleteSuggestions_.bind(this);
      $('main-content').appendChild(suggestionList);
      this.autocompleteList_ = suggestionList;
      startupPagesList.autocompleteList = suggestionList;

	  Preferences.getInstance().addEventListener('bosskey.enable', function() {
		$$('[pref="bosskey.enable"]').parents('.checkbox').nextAll('.sub-item').find(':checkbox,button').attr('disabled', 
																	!$$('[pref="bosskey.enable"]').attr('checked'));
	  });
      $('SettingbossKeyBtn').onclick = function(event) {
        chrome.send('seSetupBosskey');
      };


    },

    onHandleModifyHomePage_: function() {
      $('safemonLockHomePageTip').hidden = true;
      $('safemonLockHomePageButton').hidden = false;
      $$('[name="startup"]').removeAttr('disabled');
      $$('.mask').show();
      $$('#homepage-setting-popup textarea')[0].value = $('startupShowPagesText').textContent.replace(', ', '\n');
      $$('#homepage-setting-popup').show();
    },

    onGetDefaultAlterSearchEngine_: function(value){
    },
    /**
     * Called when the value of the instant.confirm_dialog_shown preference
     * changes. Cache this value.
     * @param {Event} event Change event.
     * @private
     */
    onInstantConfirmDialogShownChanged_: function(event) {
      this.instantConfirmDialogShown_ = event.value['value'];
    },

    /**
     * Called when the value of the instant.enabled preference changes. Request
     * the state of the Instant field trial experiment.
     * @param {Event} event Change event.
     * @private
     */
    onInstantEnabledChanged_: function(event) {
      chrome.send('getInstantFieldTrialStatus');
    },

    /**
     * Called to set the Instant field trial status.
     * @param {boolean} enabled If true, the experiment is enabled.
     * @private
     */
    setInstantFieldTrialStatus_: function(enabled) {
      $('instantEnabledCheckbox').hidden = enabled;
      $('instantFieldTrialCheckbox').hidden = !enabled;
      $('instantLabel').htmlFor = enabled ? 'instantFieldTrialCheckbox'
                                          : 'instantEnabledCheckbox';
    },

    /**
     * Called when the value of the homepage-use-NTP pref changes.
     * Updates the disabled state of the homepage text field.
     * Notice that the text field can be disabled for other reasons too
     * (it can be managed by policy, for instance).
     * @param {Event} event Change event.
     * @private
     */
    onHomepageUseNTPChanged_: function(event) {
      var homepageField = $('homepageURL');
      var homepageUseURLButton = $('homepageUseURLButton');
      homepageField.setDisabled('radioNotSelected',
                                !homepageUseURLButton.checked);
    },

    /**
     * Update the Default Browsers section based on the current state.
     * @param {string} statusString Description of the current default state.
     * @param {boolean} isDefault Whether or not the browser is currently
     *     default.
     * @param {boolean} canBeDefault Whether or not the browser can be default.
     * @private
     */
    updateDefaultBrowserState_: function(statusString, isDefault,
                                         canBeDefault) {
      var label = $('defaultBrowserState');
      label.textContent = statusString;

      $('defaultBrowserUseAsDefaultButton').disabled = !canBeDefault ||
                                                       isDefault;
    },

    /**
     * Clears the search engine popup.
     * @private
     */
    clearSearchEngines_: function() {
      //$('defaultSearchEngine').textContent = '';
	  $$('.defaultSearchEngine').text('');
    },

    /**
     * Updates the search engine popup with the given entries.
     * @param {Array} engines List of available search engines.
     * @param {number} defaultValue The value of the current default engine.
     * @param {boolean} defaultManaged Whether the default search provider is
     *     managed. If true, the default search provider can't be changed.
     */
    updateSearchEngines_: function(engines, defaultValue, defaultManaged) {
      this.clearSearchEngines_();

	  $$('.defaultSearchEngine').attr('disabled', defaultManaged);

      var defaultIndex = -1;
	  engines.forEach(function(engine, i){
        $$('.defaultSearchEngine').append(new Option(engine['name'], engine['index']));
        if (defaultValue == engine['index']) {
          defaultIndex = i;
		}
	  });

      if (defaultIndex >= 0) {
  	    $$('.defaultSearchEngine').each(function(){
			this.selectedIndex = defaultIndex;
		});
	  }
    },

    /**
     * Returns true if the custom startup page control block should
     * be enabled.
     * @returns {boolean} Whether the startup page controls should be
     *     enabled.
     */
    shouldEnableCustomStartupPageControls: function(pages) {
      return $('startupShowPagesButton').checked &&
          !this.startup_pages_pref_.disabled;
    },

    /**
     * Updates the startup pages list with the given entries.
     * @param {Array} pages List of startup pages.
     * @private
     */
    updateStartupPages_: function(pages) {
      var model = new ArrayDataModel(pages);
      // Add a "new page" row.
      //$('startupPagesList').dataModel = model;
      //this.updateCustomStartupPageControlStates_();
      var arr = [];
      for (var i = 0, len = pages.length; i < len; i++) {
        if (pages[i].url.length > 0) arr.push(pages[i].url);
      }
      $('startupShowPagesText').textContent = arr.join(', ');
      $$('#homepage-setting-popup textarea')[0].value = arr.join('\n');
    },

    /**
     * Sets the enabled state of the custom startup page list controls
     * based on the current startup radio button selection.
     * @private
     */
    updateCustomStartupPageControlStates_: function() {
      var disable = !this.shouldEnableCustomStartupPageControls();
      var startupPagesList = $('startupPagesList');
      startupPagesList.disabled = disable;
      startupPagesList.setAttribute('tabindex', disable ? -1 : 0);
      // Explicitly set disabled state for input text elements.
      var inputs = startupPagesList.querySelectorAll("input[type='text']");
      for (var i = 0; i < inputs.length; i++) {
        inputs[i].disabled = disable;
		inputs[i].placeholder = disable ? '' : (i > 0 ? '增加启动时要打开的网址' : '在此输入启动时要打开的网址');
	  }
      $('startupUseCurrentButton').disabled = disable;
    },

    /**
     * Handles change events of the preference
     * 'session.urls_to_restore_on_startup'.
     * @param {event} preference changed event.
     * @private
     */
    handleStartupPageListChange_: function(event) {
      this.startup_pages_pref_.disabled = event.value['disabled'];

      var arr = [], val = event.value.value;
      for (var i = 0, len = val.length; i < len; i++) {
        if (val[i].length > 0) arr.push(val[i]);
      }
      $('startupShowPagesText').textContent = arr.join(', ');
      $$('#homepage-setting-popup textarea')[0].value = arr.join('\n');

      //this.updateCustomStartupPageControlStates_();
    },

    /**
     * Sets the default search engine based on the popup selection.
     */
    setDefaultSearchEngine_: function() {
      var engineSelect = this;
      var selectedIndex = engineSelect.selectedIndex;
      if (selectedIndex >= 0) {
        var selection = engineSelect.options[selectedIndex];
        chrome.send('setDefaultSearchEngine', [String(selection.value)]);
      }
    },

    /**
     * Sets or clear whether Chrome should Auto-launch on computer startup.
     */
    handleAutoLaunchChanged_: function() {
      chrome.send('toggleAutoLaunch', [Boolean($('autoLaunch').checked)]);
    },

    /**
     * Sends an asynchronous request for new autocompletion suggestions for the
     * the given query. When new suggestions are available, the C++ handler will
     * call updateAutocompleteSuggestions_.
     * @param {string} query List of autocomplete suggestions.
     * @private
     */
    requestAutocompleteSuggestions_: function(query) {
      chrome.send('requestAutocompleteSuggestions', [query]);
    },

    /**
     * Updates the autocomplete suggestion list with the given entries.
     * @param {Array} pages List of autocomplete suggestions.
     * @private
     */
    updateAutocompleteSuggestions_: function(suggestions) {
      var list = this.autocompleteList_;
      // If the trigger for this update was a value being selected from the
      // current list, do nothing.
      if (list.targetInput && list.selectedItem &&
          list.selectedItem['url'] == list.targetInput.value)
        return;
      list.suggestions = suggestions;
    },

    /**
      * Shows the autoLaunch preference and initializes its checkbox value.
      */
    updateAutoLaunchState_: function(enabled) {
      $('autoLaunchOption').hidden = false;
      $('autoLaunch').checked = enabled;
    },
  };

  BrowserOptions.updateDefaultBrowserState = function(statusString, isDefault,
                                                      canBeDefault) {
    if (!cr.isChromeOS) {
      BrowserOptions.getInstance().updateDefaultBrowserState_(statusString,
                                                              isDefault,
                                                              canBeDefault);
    }
  };

  BrowserOptions.updateSearchEngines = function(engines, defaultValue,
                                                defaultManaged) {
    BrowserOptions.getInstance().updateSearchEngines_(engines, defaultValue,
                                                      defaultManaged);
  };

  BrowserOptions.onHandleModifyHomePage = function() {
    BrowserOptions.getInstance().onHandleModifyHomePage_();
  };

  BrowserOptions.updateStartupPages = function(pages) {
    BrowserOptions.getInstance().updateStartupPages_(pages);
  };

  BrowserOptions.updateAutocompleteSuggestions = function(suggestions) {
    BrowserOptions.getInstance().updateAutocompleteSuggestions_(suggestions);
  };

  BrowserOptions.updateAutoLaunchState = function(enabled) {
    BrowserOptions.getInstance().updateAutoLaunchState_(enabled);
  };

  BrowserOptions.setInstantFieldTrialStatus = function(enabled) {
    BrowserOptions.getInstance().setInstantFieldTrialStatus_(enabled);
  };

  BrowserOptions.onGetDefaultAlterSearchEngine = function(value) {
    BrowserOptions.getInstance().onGetDefaultAlterSearchEngine_(value);
  };

  // Export
  return {
    BrowserOptions: BrowserOptions
  };

});
