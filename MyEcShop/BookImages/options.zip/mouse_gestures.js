/**
 * define MouseGestures : Third Party UI Options Page
 *
 ***/
cr.define('options', function() {
  var OptionsPage = options.OptionsPage;

  function MouseGestures() {
      OptionsPage.call(this, 'mousegestures', '\u9009\u9879 - \u641C\u7D22\u680F', 'mousegesturesPage');
  }

  cr.addSingletonGetter(MouseGestures);

  window.resetMouseGesturesSuccess = function() {
    showTip('恢复默认鼠标手势成功');
    tpGetInitOptionsData();
  };

  MouseGestures.prototype = {
    __proto__: options.OptionsPage.prototype,

    tpInitOptionsMouseGestureData: [
      { key: 'IDS_MORE_SETTING_DLG_U',   pos: '0 0'},
      { key: 'IDS_MORE_SETTING_DLG_L',   pos: '-64px 0' },
      { key: 'IDS_MORE_SETTING_DLG_D',   pos: '-32px 0' },
      { key: 'IDS_MORE_SETTING_DLG_R',   pos: '-96px 0' },
      { key: 'IDS_MORE_SETTING_DLG_UD',  pos: '-320px 0' },
      { key: 'IDS_MORE_SETTING_DLG_RL',  pos: '-256px 0' },
      { key: 'IDS_MORE_SETTING_DLG_DU',  pos: '-352px 0' },
      { key: 'IDS_MORE_SETTING_DLG_LR',  pos: '-288px 0' },
      { key: 'IDS_MORE_SETTING_DLG_UL',  pos: '-128px 0' },
      { key: 'IDS_MORE_SETTING_DLG_RU',  pos: '-384px 0' },
      { key: 'IDS_MORE_SETTING_DLG_UR',  pos: '-160px 0' },
      { key: 'IDS_MORE_SETTING_DLG_RD',  pos: '-416px 0' },
      { key: 'IDS_MORE_SETTING_DLG_DL',  pos: '-192px 0' },
      { key: 'IDS_MORE_SETTING_DLG_LU',  pos: '-448px 0' },
      { key: 'IDS_MORE_SETTING_DLG_DR',  pos: '-224px 0' },
      { key: 'IDS_MORE_SETTING_DLG_LD',  pos: '-480px 0' },
      { key: 'IDS_MORE_SETTING_DLG_BA',  pos: '-512px 0' },
      { key: 'IDS_MORE_SETTING_DLG_BCU', pos: '-576px 0' },
      { key: 'IDS_MORE_SETTING_DLG_BC',  pos: '-544px 0' },
      { key: 'IDS_MORE_SETTING_DLG_BCD', pos: '-608px 0' }
    ],

    initializePage: function(){
      OptionsPage.prototype.initializePage.call(this);
      $('btn-reset-mouse-gestures').addEventListener('click', this.resetMouseGestures, false);

      Preferences.getInstance().addEventListener('browser.drag_link_to_search', function() {
        $$('[pref="se.browser.save_64k_drop_text"]').attr('disabled', !$$('[pref="browser.drag_link_to_search"]').attr('checked'));
      });

      this.buildList();
    },

    initUIData: function() {
      try{
        var tpOptionsData = templateData['tpOptionsInitData'];
        for (var i = 0, len = this.tpInitOptionsMouseGestureData.length; i < len; i++ ) {
          var key = this.tpInitOptionsMouseGestureData[i].key,
              tpOptionData = tpOptionsData[key],
              options = tpOptionData['options'],
              value = tpOptionData['value'];

          var str = '', selected = '', selectEl = $('SELECT_' + key);
          options.forEach(function(option, idx){
            selected = (value == idx) ? 'selected' : '';
            str += '<option value="' + idx + '" ' + selected + '>' + templateData[option] + '</option>';
          });
          selectEl.innerHTML = str;

          selectEl.onchange = function(){
            var k = this.id.replace('SELECT_','');
            tpOptionsData[k].value = this.value;
            templateData['tpOptionsInitData'] = tpOptionsData;
            tpSetOptionsData(k, this.value);
          }
        }
      }catch(e){
        //OptionsPage.showDefaultPage();
      }
    },

    buildList: function(){
      for (var i = 0, len = this.tpInitOptionsMouseGestureData.length; i < len; i++ ) {
        var item = this.tpInitOptionsMouseGestureData[i],
            liEl = document.createElement('li'),
            iEl = document.createElement('i'),
            spanEl = document.createElement('span'),
            selectEl = document.createElement('select');
        iEl.style.backgroundPosition = item.pos;
        liEl.appendChild(iEl);
        spanEl.innerHTML = templateData[item.key];
        liEl.appendChild(spanEl);
        selectEl.id = 'SELECT_' + item.key;
        liEl.appendChild(selectEl);
        (i < 4 ? $('basicMouseGestureList') : $('advancedMouseGestureList')).appendChild(liEl);
      }
    },

    resetMouseGestures: function() {
      really('确定要恢复到默认的鼠标手势设置吗？', function() {
        chrome.send('resetDefaultSettings', ['resetMouseGesturesSuccess',
            'kMouseGestureProfile.kMouseGestureUserMouseGesture', 'kMouseGestureProfile.kMouseGestureUserMouseGestureTips',
            'kMouseGestureProfile.U', 'kMouseGestureProfile.D', 'kMouseGestureProfile.L',
            'kMouseGestureProfile.R', 'kMouseGestureProfile.UL', 'kMouseGestureProfile.UR',
            'kMouseGestureProfile.DL', 'kMouseGestureProfile.DR', 'kMouseGestureProfile.RL',
            'kMouseGestureProfile.LR', 'kMouseGestureProfile.UD', 'kMouseGestureProfile.DU',
            'kMouseGestureProfile.RU', 'kMouseGestureProfile.RD', 'kMouseGestureProfile.LU',
            'kMouseGestureProfile.LD', 'kMouseGestureProfile.BA', 'kMouseGestureProfile.BC',
            'kMouseGestureProfile.BCU', 'kMouseGestureProfile.BCD']);
      });
      return false;
    }
  };

  return {
    MouseGestures: MouseGestures
  };
});
